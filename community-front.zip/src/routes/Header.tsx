import {Button, useDisclosure, HStack} from "@chakra-ui/react";
import LoginModal from "./LoginModal";
import Register from "./Register.tsx";

export default function Header() {
    // useDisclosure 모달의 열고 닫는 상태를 관리함
    const {
        isOpen:isLoginModalOpen,
        onOpen:onLoginModalOpen,
        onClose:onLoginModalClose
    } = useDisclosure();

       // 모달 온/오프 만들기위함
    const{
        isOpen:isRegisterOpen,
        onOpen:onRegisterOpen,
        onClose:onRegisterClose
    } = useDisclosure();


    return (
        <HStack spacing={2} justifyContent="flex-end">
            {/*로그인 버튼 (모달 열기 트리거(모달여는부분))*/}
            <Button colorScheme={"teal"} onClick={onLoginModalOpen}>
                로그인하샘
            </Button>
            {/* 모달 컴포넌트에 상태 전달 */}
            <LoginModal
        isOpen={isLoginModalOpen}
        onClose={onLoginModalClose}
            />

            {/*로그인 버튼 (모달 열기 트리거(모달여는부분) onOpen(onRegisterOpen) -> isOpen(isRegisterOpen)을 true로 만들어줌)*/}
            <Button colorScheme={"teal"} onClick={onRegisterOpen}>
                회원가입 하실?
            </Button>
            <Register
                isOpen={isRegisterOpen}
                /*onClose가 되면 isOpen이 false가 됨*/
                onClose={onRegisterClose}
            />
        </HStack>
    )
}


