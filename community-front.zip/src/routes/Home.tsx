import Header from "./Header.tsx"

export default function Home() {
    return <Header />;
}

